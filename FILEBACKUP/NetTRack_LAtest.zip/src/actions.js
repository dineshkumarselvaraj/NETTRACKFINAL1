
//action type
export const TOGGLE_MESSAGE = 'TOGGLE_MESSAGE';

//action creators
export function toggleMessage(){
    return {    
    type : TOGGLE_MESSAGE
    }
}