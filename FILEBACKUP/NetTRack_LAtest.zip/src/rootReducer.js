import {combineReducers} from 'redux'
// import movies from './movies/reducer'
// import greetings from './toggle/reducer'
// import dashboard from "./components/";
const rootReducer = combineReducers({
    // movies,
    // greetings
});

export default rootReducer;