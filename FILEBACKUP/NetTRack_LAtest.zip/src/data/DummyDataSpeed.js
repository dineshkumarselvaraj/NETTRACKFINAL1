const dataSpeedInfo = [
    { name: '11.00', UploadSpeed: 2200, DownloadSpeed: 3400, Alert: 1000 },
    { name: '11.05', UploadSpeed: 1280, DownloadSpeed: 2398, Alert: 1000 },
    { name: '11.10', UploadSpeed: 5000, DownloadSpeed: 4300, Alert: 1000 },
    { name: '11.15', UploadSpeed: 4780, DownloadSpeed: 2908, Alert: 1000 },
    { name: '11.20', UploadSpeed: 5890, DownloadSpeed: 4800, Alert: 1000 },
    { name: '11.25', UploadSpeed: 4390, DownloadSpeed: 3800, Alert: 1000 },
    { name: '11.30', UploadSpeed: 4490, DownloadSpeed: 4300, Alert: 1000 },
  ];

  
export default dataSpeedInfo;